import { redirect } from "next/navigation"
// Alternative import for newer versions:
import { auth } from "next-auth/auth"
import CustomerDashboard from "@/components/customer-dashboard"

export default async function Home() {
  // And then replace the getServerSession call with:
  const session = await auth()

  if (!session) {
    redirect("/login")
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <CustomerDashboard />
    </main>
  )
}

