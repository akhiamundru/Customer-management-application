import type { Customer } from "@/types/customer"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001"

// Helper function to handle API responses
async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = await response.json().catch(() => ({}))
    throw new Error(error.message || "An error occurred")
  }
  return response.json()
}

// Get the auth token from localStorage
function getAuthToken(): string | null {
  if (typeof window !== "undefined") {
    return localStorage.getItem("token")
  }
  return null
}

// Fetch all customers
export async function fetchCustomers(): Promise<Customer[]> {
  const token = getAuthToken()
  const response = await fetch(`${API_URL}/customers`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
  return handleResponse<Customer[]>(response)
}

// Fetch a single customer by ID
export async function fetchCustomer(id: string): Promise<Customer> {
  const token = getAuthToken()
  const response = await fetch(`${API_URL}/customers/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
  return handleResponse<Customer>(response)
}

// Create a new customer
export async function createCustomer(customer: Omit<Customer, "id">): Promise<Customer> {
  const token = getAuthToken()
  const response = await fetch(`${API_URL}/customers`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(customer),
  })
  return handleResponse<Customer>(response)
}

// Update an existing customer
export async function updateCustomer(id: string, customer: Omit<Customer, "id">): Promise<Customer> {
  const token = getAuthToken()
  const response = await fetch(`${API_URL}/customers/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(customer),
  })
  return handleResponse<Customer>(response)
}

// Delete a customer
export async function deleteCustomer(id: string): Promise<void> {
  const token = getAuthToken()
  const response = await fetch(`${API_URL}/customers/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
  return handleResponse<void>(response)
}

// Authentication API calls
export async function login(email: string, password: string): Promise<{ token: string; user: any }> {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  })
  const data = await handleResponse<{ token: string; user: any }>(response)

  // Store the token in localStorage
  if (typeof window !== "undefined" && data.token) {
    localStorage.setItem("token", data.token)
  }

  return data
}

export async function register(name: string, email: string, password: string): Promise<{ success: boolean }> {
  const response = await fetch(`${API_URL}/auth/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, email, password }),
  })
  return handleResponse<{ success: boolean }>(response)
}

export async function logout(): Promise<void> {
  if (typeof window !== "undefined") {
    localStorage.removeItem("token")
  }
  return Promise.resolve()
}

