"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CustomerList } from "@/components/customer-list"
import { CustomerForm } from "@/components/customer-form"
import { CustomerSearch } from "@/components/customer-search"
import type { Customer } from "@/types/customer"
import { fetchCustomers } from "@/lib/api"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"

export default function CustomerDashboard() {
  const { data: session } = useSession()
  const [customers, setCustomers] = useState<Customer[]>([])
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [activeTab, setActiveTab] = useState("list")

  useEffect(() => {
    const getCustomers = async () => {
      try {
        const data = await fetchCustomers()
        setCustomers(data)
        setFilteredCustomers(data)
      } catch (error) {
        console.error("Failed to fetch customers:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (session) {
      getCustomers()
    }
  }, [session])

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setFilteredCustomers(customers)
      return
    }

    const filtered = customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(query.toLowerCase()) ||
        customer.email.toLowerCase().includes(query.toLowerCase()) ||
        customer.phone.includes(query),
    )
    setFilteredCustomers(filtered)
  }

  const handleAddCustomer = (customer: Customer) => {
    setCustomers((prev) => [...prev, customer])
    setFilteredCustomers((prev) => [...prev, customer])
    setActiveTab("list")
  }

  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    const updatedCustomers = customers.map((c) => (c.id === updatedCustomer.id ? updatedCustomer : c))
    setCustomers(updatedCustomers)
    setFilteredCustomers(updatedCustomers)
    setSelectedCustomer(null)
    setActiveTab("list")
  }

  const handleEditCustomer = (customer: Customer) => {
    setSelectedCustomer(customer)
    setActiveTab("edit")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <MainNav />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Customer Management</h2>
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => {
                setSelectedCustomer(null)
                setActiveTab("add")
              }}
            >
              Add Customer
            </Button>
          </div>
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="list">Customer List</TabsTrigger>
            <TabsTrigger value="add">Add Customer</TabsTrigger>
            {selectedCustomer && <TabsTrigger value="edit">Edit Customer</TabsTrigger>}
          </TabsList>
          <TabsContent value="list" className="space-y-4">
            <Card>
              <CardContent className="pt-6">
                <CustomerSearch onSearch={handleSearch} />
                <CustomerList customers={filteredCustomers} isLoading={isLoading} onEdit={handleEditCustomer} />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="add">
            <Card>
              <CardContent className="pt-6">
                <CustomerForm onSubmit={handleAddCustomer} />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="edit">
            <Card>
              <CardContent className="pt-6">
                {selectedCustomer && <CustomerForm customer={selectedCustomer} onSubmit={handleUpdateCustomer} />}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

