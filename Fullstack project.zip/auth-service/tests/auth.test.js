import request from "supertest"
import express from "express"
import bcrypt from "bcryptjs"
import { describe, expect, it, jest } from "@jest/globals"

// Mock the express app
const app = express()

// Mock the dependencies
jest.mock("bcryptjs", () => ({
  genSalt: jest.fn().mockResolvedValue("salt"),
  hash: jest.fn().mockResolvedValue("hashedPassword"),
  compare: jest.fn().mockResolvedValue(true),
}))

jest.mock("jsonwebtoken", () => ({
  sign: jest.fn().mockReturnValue("mock-token"),
  verify: jest.fn().mockImplementation((token, secret, callback) => {
    callback(null, { id: "123", email: "test@example.com" })
  }),
}))

// Import the server after mocking dependencies
import "../server.js"

describe("Authentication Service", () => {
  describe("POST /auth/register", () => {
    it("should register a new user", async () => {
      const res = await request(app).post("/auth/register").send({
        name: "Test User",
        email: "test@example.com",
        password: "password123",
      })

      expect(res.statusCode).toEqual(201)
      expect(res.body).toHaveProperty("success", true)
    })

    it("should return 400 if required fields are missing", async () => {
      const res = await request(app).post("/auth/register").send({
        name: "Test User",
        email: "test@example.com",
      })

      expect(res.statusCode).toEqual(400)
    })
  })

  describe("POST /auth/login", () => {
    it("should login a user and return a token", async () => {
      const res = await request(app).post("/auth/login").send({
        email: "test@example.com",
        password: "password123",
      })

      expect(res.statusCode).toEqual(200)
      expect(res.body).toHaveProperty("token")
      expect(res.body).toHaveProperty("user")
    })

    it("should return 401 for invalid credentials", async () => {
      bcrypt.compare.mockResolvedValueOnce(false)

      const res = await request(app).post("/auth/login").send({
        email: "test@example.com",
        password: "wrongpassword",
      })

      expect(res.statusCode).toEqual(401)
    })
  })

  describe("GET /auth/profile", () => {
    it("should return user profile for authenticated user", async () => {
      const res = await request(app).get("/auth/profile").set("Authorization", "Bearer valid-token")

      expect(res.statusCode).toEqual(200)
      expect(res.body).toHaveProperty("id")
      expect(res.body).toHaveProperty("email")
    })

    it("should return 401 if no token is provided", async () => {
      const res = await request(app).get("/auth/profile")

      expect(res.statusCode).toEqual(401)
    })
  })
})

