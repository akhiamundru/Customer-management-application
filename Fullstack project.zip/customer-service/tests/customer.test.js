import request from "supertest"
import express from "express"
import { describe, it, expect, jest } from "@jest/globals"

// Mock the express app
const app = express()

// Mock axios
jest.mock("axios", () => ({
  post: jest.fn().mockResolvedValue({
    data: {
      valid: true,
      user: { id: "123", email: "test@example.com" },
    },
  }),
}))

// Import the server after mocking dependencies
import "../server.js"

describe("Customer Service", () => {
  describe("GET /customers", () => {
    it("should return all customers for authenticated user", async () => {
      const res = await request(app).get("/customers").set("Authorization", "Bearer valid-token")

      expect(res.statusCode).toEqual(200)
      expect(Array.isArray(res.body)).toBeTruthy()
    })

    it("should return 401 if no token is provided", async () => {
      const res = await request(app).get("/customers")

      expect(res.statusCode).toEqual(401)
    })
  })

  describe("POST /customers", () => {
    it("should create a new customer", async () => {
      const res = await request(app).post("/customers").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "john@example.com",
        phone: "1234567890",
        address: "123 Main St",
      })

      expect(res.statusCode).toEqual(201)
      expect(res.body).toHaveProperty("id")
      expect(res.body.name).toEqual("John Doe")
    })

    it("should return 400 if required fields are missing", async () => {
      const res = await request(app).post("/customers").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "john@example.com",
      })

      expect(res.statusCode).toEqual(400)
    })

    it("should return 400 if email format is invalid", async () => {
      const res = await request(app).post("/customers").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "invalid-email",
        phone: "1234567890",
      })

      expect(res.statusCode).toEqual(400)
    })
  })

  describe("PUT /customers/:id", () => {
    it("should update an existing customer", async () => {
      // First create a customer
      const createRes = await request(app).post("/customers").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "john@example.com",
        phone: "1234567890",
      })

      const customerId = createRes.body.id

      // Then update the customer
      const updateRes = await request(app)
        .put(`/customers/${customerId}`)
        .set("Authorization", "Bearer valid-token")
        .send({
          name: "John Updated",
          email: "john.updated@example.com",
          phone: "0987654321",
        })

      expect(updateRes.statusCode).toEqual(200)
      expect(updateRes.body.name).toEqual("John Updated")
      expect(updateRes.body.email).toEqual("john.updated@example.com")
    })

    it("should return 404 if customer is not found", async () => {
      const res = await request(app).put("/customers/non-existent-id").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "john@example.com",
        phone: "1234567890",
      })

      expect(res.statusCode).toEqual(404)
    })
  })

  describe("DELETE /customers/:id", () => {
    it("should delete an existing customer", async () => {
      // First create a customer
      const createRes = await request(app).post("/customers").set("Authorization", "Bearer valid-token").send({
        name: "John Doe",
        email: "john@example.com",
        phone: "1234567890",
      })

      const customerId = createRes.body.id

      // Then delete the customer
      const deleteRes = await request(app).delete(`/customers/${customerId}`).set("Authorization", "Bearer valid-token")

      expect(deleteRes.statusCode).toEqual(204)

      // Verify the customer is deleted
      const getRes = await request(app).get(`/customers/${customerId}`).set("Authorization", "Bearer valid-token")

      expect(getRes.statusCode).toEqual(404)
    })
  })
})

