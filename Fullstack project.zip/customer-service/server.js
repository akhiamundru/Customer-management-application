import express from "express"
import cors from "cors"
import { v4 as uuidv4 } from "uuid"
import axios from "axios"

const app = express()
const PORT = process.env.PORT || 3001
const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || "http://localhost:3000"

// In-memory database for demo purposes
// In a real application, you would use a proper database
const customers = []

app.use(cors())
app.use(express.json())

// Middleware to verify JWT token with Auth Service
const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ message: "Unauthorized: No token provided" })
  }

  try {
    // Verify token with Auth Service
    const response = await axios.post(
      `${AUTH_SERVICE_URL}/auth/verify`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    )

    req.user = response.data.user
    next()
  } catch (error) {
    console.error("Token verification error:", error.message)
    return res.status(403).json({ message: "Forbidden: Invalid token" })
  }
}

// Get all customers
app.get("/customers", authenticateToken, (req, res) => {
  res.json(customers)
})

// Get customer by ID
app.get("/customers/:id", authenticateToken, (req, res) => {
  const customer = customers.find((c) => c.id === req.params.id)

  if (!customer) {
    return res.status(404).json({ message: "Customer not found" })
  }

  res.json(customer)
})

// Create a new customer
app.post("/customers", authenticateToken, (req, res) => {
  const { name, email, phone, address } = req.body

  // Validate input
  if (!name || !email || !phone) {
    return res.status(400).json({ message: "Name, email, and phone are required" })
  }

  // Validate email format
  const emailRegex = /\S+@\S+\.\S+/
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Invalid email format" })
  }

  // Create new customer
  const newCustomer = {
    id: uuidv4(),
    name,
    email,
    phone,
    address: address || "",
    createdAt: new Date(),
    createdBy: req.user.id,
  }

  customers.push(newCustomer)

  res.status(201).json(newCustomer)
})

// Update a customer
app.put("/customers/:id", authenticateToken, (req, res) => {
  const { name, email, phone, address } = req.body
  const customerIndex = customers.findIndex((c) => c.id === req.params.id)

  if (customerIndex === -1) {
    return res.status(404).json({ message: "Customer not found" })
  }

  // Validate input
  if (!name || !email || !phone) {
    return res.status(400).json({ message: "Name, email, and phone are required" })
  }

  // Validate email format
  const emailRegex = /\S+@\S+\.\S+/
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Invalid email format" })
  }

  // Update customer
  customers[customerIndex] = {
    ...customers[customerIndex],
    name,
    email,
    phone,
    address: address || "",
    updatedAt: new Date(),
    updatedBy: req.user.id,
  }

  res.json(customers[customerIndex])
})

// Delete a customer
app.delete("/customers/:id", authenticateToken, (req, res) => {
  const customerIndex = customers.findIndex((c) => c.id === req.params.id)

  if (customerIndex === -1) {
    return res.status(404).json({ message: "Customer not found" })
  }

  customers.splice(customerIndex, 1)

  res.status(204).send()
})

// Search customers
app.get("/customers/search", authenticateToken, (req, res) => {
  const { query } = req.query

  if (!query) {
    return res.json(customers)
  }

  const searchQuery = query.toString().toLowerCase()
  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchQuery) ||
      customer.email.toLowerCase().includes(searchQuery) ||
      customer.phone.includes(searchQuery),
  )

  res.json(filteredCustomers)
})

app.listen(PORT, () => {
  console.log(`Customer service running on port ${PORT}`)
})

