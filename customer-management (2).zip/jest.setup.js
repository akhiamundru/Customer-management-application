import "@testing-library/jest-dom"
import { TextEncoder, TextDecoder } from "util"
import { jest } from "@jest/globals"

global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder

// Mock Next.js router
jest.mock("next/navigation", () => ({
  useRouter: () => ({
    push: jest.fn(),
    back: jest.fn(),
    refresh: jest.fn(),
  }),
  useSearchParams: () => ({
    get: jest.fn(),
  }),
  usePathname: () => "",
}))

// Mock next-auth
jest.mock("next-auth/react", () => ({
  useSession: jest.fn(() => ({
    data: { user: { name: "Test User", email: "test@example.com" } },
    status: "authenticated",
  })),
  signIn: jest.fn(),
  signOut: jest.fn(),
}))

// Mock server session
jest.mock("next-auth/next", () => ({
  getServerSession: jest.fn(() => ({
    user: { name: "Test User", email: "test@example.com" },
  })),
}))

