import { db } from "@/lib/db"
import { validateEmail, validatePhone } from "@/lib/validation"
import type { Customer } from "@/lib/types"

export class CustomerService {
  /**
   * Get all customers with optional search
   */
  static async getCustomers(search?: string): Promise<Customer[]> {
    try {
      return await db.customer.findMany({
        where: search
          ? {
              OR: [
                { name: { contains: search, mode: "insensitive" } },
                { email: { contains: search, mode: "insensitive" } },
                { company: { contains: search, mode: "insensitive" } },
              ],
            }
          : undefined,
        orderBy: { createdAt: "desc" },
      })
    } catch (error) {
      console.error("Error fetching customers:", error)
      throw new Error("Failed to fetch customers")
    }
  }

  /**
   * Get a customer by ID
   */
  static async getCustomerById(id: string): Promise<Customer | null> {
    try {
      return await db.customer.findUnique({
        where: { id },
      })
    } catch (error) {
      console.error(`Error fetching customer ${id}:`, error)
      throw new Error("Failed to fetch customer")
    }
  }

  /**
   * Create a new customer
   */
  static async createCustomer(data: {
    name: string
    email: string
    phone?: string
    company?: string
    address?: string
  }): Promise<Customer> {
    try {
      const { name, email, phone, company, address } = data

      // Validate required fields
      if (!name || !email) {
        throw new Error("Name and email are required")
      }

      // Validate email format
      if (!validateEmail(email)) {
        throw new Error("Invalid email format")
      }

      // Validate phone if provided
      if (phone && !validatePhone(phone)) {
        throw new Error("Invalid phone number format")
      }

      // Check if customer with this email already exists
      const existingCustomer = await db.customer.findUnique({
        where: { email },
      })

      if (existingCustomer) {
        throw new Error("Customer with this email already exists")
      }

      // Create customer
      return await db.customer.create({
        data: {
          name,
          email,
          phone: phone || null,
          company: company || null,
          address: address || null,
        },
      })
    } catch (error) {
      console.error("Error creating customer:", error)
      if (error instanceof Error) {
        throw error
      }
      throw new Error("Failed to create customer")
    }
  }

  /**
   * Update a customer
   */
  static async updateCustomer(
    id: string,
    data: {
      name: string
      email: string
      phone?: string
      company?: string
      address?: string
    },
  ): Promise<Customer> {
    try {
      const { name, email, phone, company, address } = data

      // Validate required fields
      if (!name || !email) {
        throw new Error("Name and email are required")
      }

      // Validate email format
      if (!validateEmail(email)) {
        throw new Error("Invalid email format")
      }

      // Validate phone if provided
      if (phone && !validatePhone(phone)) {
        throw new Error("Invalid phone number format")
      }

      // Check if customer exists
      const existingCustomer = await db.customer.findUnique({
        where: { id },
      })

      if (!existingCustomer) {
        throw new Error("Customer not found")
      }

      // Check if email is already used by another customer
      if (email !== existingCustomer.email) {
        const customerWithEmail = await db.customer.findUnique({
          where: { email },
        })

        if (customerWithEmail) {
          throw new Error("Email is already in use by another customer")
        }
      }

      // Update customer
      return await db.customer.update({
        where: { id },
        data: {
          name,
          email,
          phone: phone || null,
          company: company || null,
          address: address || null,
        },
      })
    } catch (error) {
      console.error(`Error updating customer ${id}:`, error)
      if (error instanceof Error) {
        throw error
      }
      throw new Error("Failed to update customer")
    }
  }

  /**
   * Delete a customer
   */
  static async deleteCustomer(id: string): Promise<void> {
    try {
      // Check if customer exists
      const customer = await db.customer.findUnique({
        where: { id },
      })

      if (!customer) {
        throw new Error("Customer not found")
      }

      // Delete customer
      await db.customer.delete({
        where: { id },
      })
    } catch (error) {
      console.error(`Error deleting customer ${id}:`, error)
      if (error instanceof Error) {
        throw error
      }
      throw new Error("Failed to delete customer")
    }
  }
}

