import { hash, compare } from "bcrypt"
import { db } from "@/lib/db"
import { validateEmail } from "@/lib/validation"

export class AuthService {
  /**
   * Register a new user
   */
  static async registerUser(name: string, email: string, password: string) {
    // Validate input
    if (!name || !email || !password) {
      throw new Error("Missing required fields")
    }

    if (!validateEmail(email)) {
      throw new Error("Invalid email format")
    }

    if (password.length < 6) {
      throw new Error("Password must be at least 6 characters")
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      throw new Error("User with this email already exists")
    }

    // Hash password
    const hashedPassword = await hash(password, 10)

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
      },
    })

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return userWithoutPassword
  }

  /**
   * Authenticate a user
   */
  static async authenticateUser(email: string, password: string) {
    // Validate input
    if (!email || !password) {
      throw new Error("Email and password are required")
    }

    // Find user
    const user = await db.user.findUnique({
      where: { email },
    })

    if (!user) {
      throw new Error("Invalid credentials")
    }

    // Verify password
    const isPasswordValid = await compare(password, user.password)

    if (!isPasswordValid) {
      throw new Error("Invalid credentials")
    }

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return userWithoutPassword
  }

  /**
   * Get user by ID
   */
  static async getUserById(id: string) {
    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true,
        updatedAt: true,
      },
    })

    return user
  }
}

