import { hash } from "bcrypt"
import { db } from "./db"
import { createLogger } from "./logger"

const logger = createLogger("DatabaseSeed")

/**
 * Seed the database with initial data
 */
export async function seedDatabase() {
  try {
    logger.info("Starting database seed")

    // Check if we already have users
    const userCount = await db.user.count()

    if (userCount === 0) {
      logger.info("Seeding admin user")

      // Create admin user
      const hashedPassword = await hash("admin123", 10)

      await db.user.create({
        data: {
          name: "Admin User",
          email: "admin@example.com",
          password: hashedPassword,
        },
      })

      logger.info("Admin user created")
    } else {
      logger.info("Users already exist, skipping user seed")
    }

    // Check if we already have customers
    const customerCount = await db.customer.count()

    if (customerCount === 0) {
      logger.info("Seeding sample customers")

      // Create sample customers
      const customers = [
        {
          name: "John Doe",
          email: "john@example.com",
          phone: "555-123-4567",
          company: "Acme Inc",
          address: "123 Main St, Anytown, USA",
        },
        {
          name: "Jane Smith",
          email: "jane@example.com",
          phone: "555-987-6543",
          company: "Globex Corp",
          address: "456 Oak Ave, Somewhere, USA",
        },
        {
          name: "Bob Johnson",
          email: "bob@example.com",
          phone: "555-555-5555",
          company: "ABC Company",
          address: "789 Pine Rd, Nowhere, USA",
        },
      ]

      for (const customer of customers) {
        await db.customer.create({ data: customer })
      }

      logger.info(`Created ${customers.length} sample customers`)
    } else {
      logger.info("Customers already exist, skipping customer seed")
    }

    logger.info("Database seed completed successfully")
  } catch (error) {
    logger.error("Error seeding database", error)
    throw error
  }
}

