import { db } from "@/lib/db"
import type { Customer } from "@/lib/types"

export async function getCustomers(search?: string): Promise<Customer[]> {
  try {
    return await db.customer.findMany({
      where: search
        ? {
            OR: [
              { name: { contains: search, mode: "insensitive" } },
              { email: { contains: search, mode: "insensitive" } },
              { company: { contains: search, mode: "insensitive" } },
            ],
          }
        : undefined,
      orderBy: { createdAt: "desc" },
    })
  } catch (error) {
    console.error("Error fetching customers:", error)
    return []
  }
}

export async function getCustomerById(id: string): Promise<Customer | null> {
  try {
    return await db.customer.findUnique({
      where: { id },
    })
  } catch (error) {
    console.error(`Error fetching customer ${id}:`, error)
    return null
  }
}

