type LogLevel = "debug" | "info" | "warn" | "error"

class Logger {
  private context: string

  constructor(context: string) {
    this.context = context
  }

  private log(level: LogLevel, message: string, meta?: any) {
    const timestamp = new Date().toISOString()
    const logData = {
      timestamp,
      level,
      context: this.context,
      message,
      ...(meta ? { meta } : {}),
    }

    // In production, you might want to use a proper logging service
    if (process.env.NODE_ENV === "production") {
      // Send logs to a service like Datadog, Sentry, etc.
      console[level === "debug" ? "log" : level](JSON.stringify(logData))
    } else {
      // In development, pretty print logs
      const colorMap = {
        debug: "\x1b[34m", // blue
        info: "\x1b[32m", // green
        warn: "\x1b[33m", // yellow
        error: "\x1b[31m", // red
      }

      const reset = "\x1b[0m"
      const color = colorMap[level]

      console[level === "debug" ? "log" : level](
        `${color}[${timestamp}] [${level.toUpperCase()}] [${this.context}]${reset} ${message}`,
        meta ? meta : "",
      )
    }
  }

  debug(message: string, meta?: any) {
    if (process.env.NODE_ENV !== "production") {
      this.log("debug", message, meta)
    }
  }

  info(message: string, meta?: any) {
    this.log("info", message, meta)
  }

  warn(message: string, meta?: any) {
    this.log("warn", message, meta)
  }

  error(message: string, error?: any) {
    this.log("error", message, error)
  }
}

export function createLogger(context: string) {
  return new Logger(context)
}

