import { NextResponse } from "next/server"
import { createLogger } from "./logger"

const logger = createLogger("ErrorHandler")

export class AppError extends Error {
  statusCode: number

  constructor(message: string, statusCode = 500) {
    super(message)
    this.statusCode = statusCode
    this.name = "AppError"
  }
}

export function handleApiError(error: unknown) {
  if (error instanceof AppError) {
    logger.warn(`API Error: ${error.message}`, { statusCode: error.statusCode })
    return NextResponse.json({ message: error.message }, { status: error.statusCode })
  }

  // For unexpected errors
  const message = error instanceof Error ? error.message : "An unexpected error occurred"
  logger.error(`Unexpected API Error: ${message}`, error)

  return NextResponse.json({ message: "Internal server error" }, { status: 500 })
}

