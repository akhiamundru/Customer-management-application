import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Public paths that don't require authentication
  const isPublicPath = path === "/login" || path === "/register"

  // Check if the request is for the API
  const isApiPath = path.startsWith("/api")

  // Get the token from the request
  const token = await getToken({
    req: request,
    secret: process.env.NEXTAUTH_SECRET,
  })

  // If the path is public and the user is logged in, redirect to the dashboard
  if (isPublicPath && token) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  // If the path is not public and the user is not logged in, redirect to the login page
  if (!isPublicPath && !token && !isApiPath) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // If the path is an API route and the user is not logged in, return an unauthorized response
  // Except for the auth API routes
  if (isApiPath && !token && !path.startsWith("/api/auth")) {
    return new NextResponse(JSON.stringify({ message: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    })
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}

