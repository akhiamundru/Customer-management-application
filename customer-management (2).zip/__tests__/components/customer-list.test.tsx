import { render, screen } from "@testing-library/react"
import { CustomerList } from "@/components/customer-list"
import * as customerLib from "@/lib/customers"

// Mock the customers library
jest.mock("@/lib/customers", () => ({
  getCustomers: jest.fn(),
}))

// Mock next/navigation
jest.mock("next/navigation", () => ({
  useRouter: () => ({
    push: jest.fn(),
    refresh: jest.fn(),
  }),
}))

describe("CustomerList", () => {
  it("renders a list of customers", async () => {
    const mockCustomers = [
      {
        id: "1",
        name: "John Doe",
        email: "john@example.com",
        phone: "555-123-4567",
        company: "Acme Inc",
        address: "123 Main St",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "2",
        name: "Jane Smith",
        email: "jane@example.com",
        phone: null,
        company: null,
        address: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]

    // @ts-ignore - mocking
    jest.spyOn(customerLib, "getCustomers").mockResolvedValue(mockCustomers)

    render(await CustomerList())

    expect(screen.getByText("John Doe")).toBeInTheDocument()
    expect(screen.getByText("john@example.com")).toBeInTheDocument()
    expect(screen.getByText("Jane Smith")).toBeInTheDocument()
    expect(screen.getByText("jane@example.com")).toBeInTheDocument()
  })

  it("renders a message when no customers are found", async () => {
    // @ts-ignore - mocking
    jest.spyOn(customerLib, "getCustomers").mockResolvedValue([])

    render(await CustomerList())

    expect(screen.getByText("No customers found. Add your first customer to get started.")).toBeInTheDocument()
  })

  it("renders a different message when search returns no results", async () => {
    // @ts-ignore - mocking
    jest.spyOn(customerLib, "getCustomers").mockResolvedValue([])

    render(await CustomerList({ searchQuery: "nonexistent" }))

    expect(screen.getByText("No customers found matching your search criteria.")).toBeInTheDocument()
  })
})

