import { CustomerService } from "@/lib/services/customer-service"
import { db } from "@/lib/db"
import { describe, beforeEach, it, expect, jest } from "@jest/globals"

// Mock the Prisma client
jest.mock("@/lib/db", () => ({
  db: {
    customer: {
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
  },
}))

describe("CustomerService", () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  describe("getCustomers", () => {
    it("should return all customers when no search is provided", async () => {
      const mockCustomers = [
        { id: "1", name: "John Doe", email: "john@example.com" },
        { id: "2", name: "Jane Smith", email: "jane@example.com" },
      ]

      // @ts-ignore - mocking
      db.customer.findMany.mockResolvedValue(mockCustomers)

      const result = await CustomerService.getCustomers()

      expect(result).toEqual(mockCustomers)
      expect(db.customer.findMany).toHaveBeenCalledWith({
        where: undefined,
        orderBy: { createdAt: "desc" },
      })
    })

    it("should filter customers when search is provided", async () => {
      const mockCustomers = [{ id: "1", name: "John Doe", email: "john@example.com" }]

      // @ts-ignore - mocking
      db.customer.findMany.mockResolvedValue(mockCustomers)

      const result = await CustomerService.getCustomers("John")

      expect(result).toEqual(mockCustomers)
      expect(db.customer.findMany).toHaveBeenCalledWith({
        where: {
          OR: [
            { name: { contains: "John", mode: "insensitive" } },
            { email: { contains: "John", mode: "insensitive" } },
            { company: { contains: "John", mode: "insensitive" } },
          ],
        },
        orderBy: { createdAt: "desc" },
      })
    })
  })

  describe("createCustomer", () => {
    it("should create a new customer with valid data", async () => {
      const customerData = {
        name: "John Doe",
        email: "john@example.com",
        phone: "555-123-4567",
      }

      const createdCustomer = {
        id: "1",
        ...customerData,
        company: null,
        address: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      // @ts-ignore - mocking
      db.customer.findUnique.mockResolvedValue(null)
      // @ts-ignore - mocking
      db.customer.create.mockResolvedValue(createdCustomer)

      const result = await CustomerService.createCustomer(customerData)

      expect(result).toEqual(createdCustomer)
      expect(db.customer.create).toHaveBeenCalledWith({
        data: {
          name: "John Doe",
          email: "john@example.com",
          phone: "555-123-4567",
          company: null,
          address: null,
        },
      })
    })

    it("should throw an error if email is invalid", async () => {
      const customerData = {
        name: "John Doe",
        email: "invalid-email",
      }

      await expect(CustomerService.createCustomer(customerData)).rejects.toThrow("Invalid email format")
    })

    it("should throw an error if customer with email already exists", async () => {
      const customerData = {
        name: "John Doe",
        email: "john@example.com",
      }

      // @ts-ignore - mocking
      db.customer.findUnique.mockResolvedValue({ id: "1", email: "john@example.com" })

      await expect(CustomerService.createCustomer(customerData)).rejects.toThrow(
        "Customer with this email already exists",
      )
    })
  })
})

