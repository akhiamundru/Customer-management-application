import { Suspense } from "react"
import Link from "next/link"
import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"

import { authOptions } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { CustomerList } from "@/components/customer-list"
import { SearchForm } from "@/components/search-form"

export default async function Home() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  return (
    <main className="container mx-auto py-6 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Customer Management</h1>
        <div className="flex gap-4">
          <Link href="/customers/new">
            <Button>Add Customer</Button>
          </Link>
          <Link href="/api/auth/signout">
            <Button variant="outline">Sign Out</Button>
          </Link>
        </div>
      </div>

      <div className="mb-6">
        <SearchForm />
      </div>

      <Suspense fallback={<div>Loading customers...</div>}>
        <CustomerList />
      </Suspense>
    </main>
  )
}

