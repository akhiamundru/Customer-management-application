import { type NextRequest, NextResponse } from "next/server"
import { AuthService } from "@/lib/services/auth-service"
import { handleApiError } from "@/lib/error-handler"
import { createLogger } from "@/lib/logger"

const logger = createLogger("RegisterAPI")

export async function POST(request: NextRequest) {
  try {
    const { name, email, password } = await request.json()

    logger.info(`Registering new user: ${email}`)

    const user = await AuthService.registerUser(name, email, password)

    return NextResponse.json({ message: "User registered successfully", user }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}

