import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { CustomerService } from "@/lib/services/customer-service"
import { handleApiError, AppError } from "@/lib/error-handler"
import { createLogger } from "@/lib/logger"

const logger = createLogger("CustomersAPI")

// GET all customers with optional search
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      throw new AppError("Unauthorized", 401)
    }

    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")

    logger.info(`Fetching customers${search ? ` with search: ${search}` : ""}`)

    const customers = await CustomerService.getCustomers(search || undefined)

    return NextResponse.json(customers)
  } catch (error) {
    return handleApiError(error)
  }
}

// POST create a new customer
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      throw new AppError("Unauthorized", 401)
    }

    const body = await request.json()

    logger.info("Creating new customer", { email: body.email })

    const customer = await CustomerService.createCustomer(body)

    return NextResponse.json(customer, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}

