import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { CustomerService } from "@/lib/services/customer-service"
import { handleApiError, AppError } from "@/lib/error-handler"
import { createLogger } from "@/lib/logger"

const logger = createLogger("CustomerDetailAPI")

// GET a specific customer by ID
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      throw new AppError("Unauthorized", 401)
    }

    logger.info(`Fetching customer with ID: ${params.id}`)

    const customer = await CustomerService.getCustomerById(params.id)

    if (!customer) {
      throw new AppError("Customer not found", 404)
    }

    return NextResponse.json(customer)
  } catch (error) {
    return handleApiError(error)
  }
}

// PUT update a customer
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      throw new AppError("Unauthorized", 401)
    }

    const body = await request.json()

    logger.info(`Updating customer with ID: ${params.id}`)

    const customer = await CustomerService.updateCustomer(params.id, body)

    return NextResponse.json(customer)
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE a customer
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      throw new AppError("Unauthorized", 401)
    }

    logger.info(`Deleting customer with ID: ${params.id}`)

    await CustomerService.deleteCustomer(params.id)

    return NextResponse.json({ message: "Customer deleted successfully" }, { status: 200 })
  } catch (error) {
    return handleApiError(error)
  }
}

