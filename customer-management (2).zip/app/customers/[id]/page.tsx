import { notFound } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { getCustomerById } from "@/lib/customers"
import { CustomerDetail } from "@/components/customer-detail"

export default async function CustomerPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return {
      redirect: {
        destination: "/login",
        permanent: false,
      },
    }
  }

  const customer = await getCustomerById(params.id)

  if (!customer) {
    notFound()
  }

  return <CustomerDetail customer={customer} />
}

