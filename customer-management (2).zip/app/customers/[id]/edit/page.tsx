import { notFound } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { getCustomerById } from "@/lib/customers"
import { CustomerEditForm } from "@/components/customer-edit-form"

export default async function EditCustomerPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return {
      redirect: {
        destination: "/login",
        permanent: false,
      },
    }
  }

  const customer = await getCustomerById(params.id)

  if (!customer) {
    notFound()
  }

  return <CustomerEditForm customer={customer} />
}

